# Teams Bot → Whisper → Vexa.AI (Live Subtitles)
(This is the master documentation file — all other files are referenced inside.)
